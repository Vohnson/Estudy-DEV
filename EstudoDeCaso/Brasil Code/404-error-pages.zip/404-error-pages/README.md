# 404 Error Pages

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/WNYvjZN](https://codepen.io/Codewithshobhit/pen/WNYvjZN).

Interesting 404 error page.