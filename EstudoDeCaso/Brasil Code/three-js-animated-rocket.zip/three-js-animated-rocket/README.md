# Three.js animated rocket

A Pen created on CodePen.io. Original URL: [https://codepen.io/stivaliserna/pen/rNMwpaG](https://codepen.io/stivaliserna/pen/rNMwpaG).

https://twitter.com/stivaliserna/status/1340001805988753408