# Product Card for shoe 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/OJBwmgj](https://codepen.io/Codewithshobhit/pen/OJBwmgj).

