# Text Stroke Animation

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/xxyBVjL](https://codepen.io/Codewithshobhit/pen/xxyBVjL).

CSS SVG Text Stroke Animation. 
Only the button uses javascript to restart the animation.