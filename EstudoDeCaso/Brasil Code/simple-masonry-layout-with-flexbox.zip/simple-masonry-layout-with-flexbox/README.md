# Simple Masonry Layout With Flexbox

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/JjeoLmP](https://codepen.io/Codewithshobhit/pen/JjeoLmP).

An early experiment. Requires Blink, Webkit or Firefox 28+; photographs by [Sean Archer](http://500px.com/SeanArcher), [Complete article](http://thenewcode.com/844/Easy-Masonry-Layout-With-Flexbox). Improved substantially in [this pen](http://codepen.io/dudleystorey/pen/KreAx)