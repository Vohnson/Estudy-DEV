# 3D Card hover effect (CSS only)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/JjmgxBg](https://codepen.io/Codewithshobhit/pen/JjmgxBg).

Hover the card and see the 3D Character coming your way 👀