# Let there be light 💡

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/gOBMQNX](https://codepen.io/Codewithshobhit/pen/gOBMQNX).

Based on [Switch On/Off - DailyUI #015](https://dribbble.com/shots/3032158-Switch-On-Off-DailyUI-015) by [lanars.](https://dribbble.com/lanars)