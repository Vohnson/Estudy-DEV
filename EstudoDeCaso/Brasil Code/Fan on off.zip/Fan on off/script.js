// let a=document.querySelector("img");
let a=document.getElementById("img");

function myfunon()
{
a.style.animationDuration = 3+"s";
}
function myfunoff()
{
    a.style.animationDuration=0+"s";
}
function myfun2()
{
    a.style.animationDuration=1+"s";
}
function myfun3()
{
    a.style.animationDuration=0.5+"s";
}
function myfun4()
{
    a.style.animationDuration=0.1+"s";
}
