# Honey comb menu bar

A Pen created on CodePen.io. Original URL: [https://codepen.io/Palak2/pen/mdXgZXK](https://codepen.io/Palak2/pen/mdXgZXK).

