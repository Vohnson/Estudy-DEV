function rand(max) {
	return Math.floor(Math.random() * max);
}

// 这个函数用于打乱数组a的顺序。它使用了Fisher-Yates算法，也被称为Knuth洗牌算法
function shuffle(a) {
	for (let i = a.length - 1; i > 0; i--) {
		const j = Math.floor(Math.random() * (i + 1));
		[a[i], a[j]] = [a[j], a[i]];
	}
	return a;
}

// 这个函数用于改变图像的亮度。
function changeBrightness(factor, sprite) {
	var virtCanvas = document.createElement("canvas");
	virtCanvas.width = 500;
	virtCanvas.height = 500;
	var context = virtCanvas.getContext("2d");
	context.drawImage(sprite, 0, 0, 500, 500);

	var imgData = context.getImageData(0, 0, 500, 500);

	for (let i = 0; i < imgData.data.length; i += 4) {
		imgData.data[i] = imgData.data[i] * factor;
		imgData.data[i + 1] = imgData.data[i + 1] * factor;
		imgData.data[i + 2] = imgData.data[i + 2] * factor;
	}
	context.putImageData(imgData, 0, 0);

	var spriteOutput = new Image();
	spriteOutput.src = virtCanvas.toDataURL();
	virtCanvas.remove();
	return spriteOutput;
}

function toggleVisablity(id) {
	if (document.getElementById(id).style.visibility == "visible") {
		document.getElementById(id).style.visibility = "hidden";
	} else {
		document.getElementById(id).style.visibility = "visible";
	}
}

// ------------------------------------------------------------------ 生成一个迷宫
function Maze(Width, Height) {
	var mazeMap; // 用于存储迷宫的地图
	var width = Width;
	var height = Height;
	var startCoord, endCoord; // 迷宫的起点和终点坐标
	var dirs = ["n", "s", "e", "w"]; // 四个方向的数组
	var modDir = {
		// 一个对象，用于根据方向修改坐标
		n: {
			y: -1,
			x: 0,
			o: "s",
		},
		s: {
			y: 1,
			x: 0,
			o: "n",
		},
		e: {
			y: 0,
			x: 1,
			o: "w",
		},
		w: {
			y: 0,
			x: -1,
			o: "e",
		},
	};

	this.map = function () {
		return mazeMap;
	};
	this.startCoord = function () {
		return startCoord;
	};
	this.endCoord = function () {
		return endCoord;
	};

	// 生成迷宫的地图
	function genMap() {
		mazeMap = new Array(height);
		for (y = 0; y < height; y++) {
			mazeMap[y] = new Array(width);
			for (x = 0; x < width; ++x) {
				mazeMap[y][x] = {
					n: false,
					s: false,
					e: false,
					w: false, // 四个方向的墙
					visited: false, // 是否被访问过
					priorPos: null, // 前一个位置
				};
			}
		}
	}

	// 定义迷宫的路径
	function defineMaze() {
		var isComp = false;
		var move = false;
		var cellsVisited = 1;
		var numLoops = 0;
		var maxLoops = 0;
		var pos = {
			x: 0,
			y: 0,
		};
		var numCells = width * height;
		while (!isComp) {
			move = false;
			mazeMap[pos.x][pos.y].visited = true;

			if (numLoops >= maxLoops) {
				shuffle(dirs);
				maxLoops = Math.round(rand(height / 8));
				numLoops = 0;
			}
			numLoops++;
			for (index = 0; index < dirs.length; index++) {
				var direction = dirs[index];
				var nx = pos.x + modDir[direction].x;
				var ny = pos.y + modDir[direction].y;

				if (nx >= 0 && nx < width && ny >= 0 && ny < height) {
					//Check if the tile is already visited
					if (!mazeMap[nx][ny].visited) {
						//Carve through walls from this tile to next
						mazeMap[pos.x][pos.y][direction] = true;
						mazeMap[nx][ny][modDir[direction].o] = true;

						//Set Currentcell as next cells Prior visited
						mazeMap[nx][ny].priorPos = pos;
						//Update Cell position to newly visited location
						pos = {
							x: nx,
							y: ny,
						};
						cellsVisited++;
						//Recursively call this method on the next tile
						move = true;
						break;
					}
				}
			}

			if (!move) {
				//  如果未能找到一个方向，将当前位置移回先前的单元格并重新调用该方法
				pos = mazeMap[pos.x][pos.y].priorPos;
			}
			if (numCells == cellsVisited) {
				isComp = true;
			}
		}
	}

	// 定义迷宫的起点和终点
	function defineStartEnd() {
		switch (rand(4)) {
			case 0:
				startCoord = {
					x: 0,
					y: 0,
				};
				endCoord = {
					x: height - 1,
					y: width - 1,
				};
				break;
			case 1:
				startCoord = {
					x: 0,
					y: width - 1,
				};
				endCoord = {
					x: height - 1,
					y: 0,
				};
				break;
			case 2:
				startCoord = {
					x: height - 1,
					y: 0,
				};
				endCoord = {
					x: 0,
					y: width - 1,
				};
				break;
			case 3:
				startCoord = {
					x: height - 1,
					y: width - 1,
				};
				endCoord = {
					x: 0,
					y: 0,
				};
				break;
		}
	}

	genMap();
	defineStartEnd();
	defineMaze();
}

// ------------------------------------------------------------------ 在canvas上绘制迷宫
function DrawMaze(Maze, ctx, cellsize, endSprite = null) {
	var map = Maze.map();
	var cellSize = cellsize;
	var drawEndMethod;
	ctx.lineWidth = cellSize / 40;

	// Fog 默认关闭
	this.fog = false;

	// 开启fog模式的音效
	this.enableFog = function () {
		this.fog = true;
		document.getElementById("fogOn").play();
	};

	// 关闭fog模式的音效
	this.disableFog = function () {
		this.fog = false;
		document.getElementById("fogOff").play();
	};

	// 绘制 Fog
	this.drawFog = function (playerCoords) {
		// 重新绘制迷宫，以让迷宫的墙始终可见
		drawMap();
		// 首先，我们使用黑色填充整个迷宫，创建迷雾效果
		ctx.fillStyle = "rgba(0, 0, 0, 0.5)";
		ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);

		// 然后，我们计算玩家周围应该可见的区域的大小
		var visibleRadius = cellSize * Math.round(map.length * 0.12);

		// 接着，我们创建一个径向渐变，从完全透明渐变到完全不透明
		var gradient = ctx.createRadialGradient(
			(playerCoords.x + 0.5) * cellSize,
			(playerCoords.y + 0.5) * cellSize,
			0,
			(playerCoords.x + 0.5) * cellSize,
			(playerCoords.y + 0.5) * cellSize,
			visibleRadius
		);
		/*gradient.addColorStop(0, "rgba(0, 0, 0, 0)");
		gradient.addColorStop(1, "rgba(0, 0, 0, 0.5)");*/
		gradient.addColorStop(0.65, "rgba(0, 0, 0, 0.5)");
		gradient.addColorStop(1, "rgba(0, 0, 0, 0.2)"); // 0.2 让终点微微发亮

		// 最后，我们使用这个渐变来清除玩家周围的迷雾
		ctx.globalCompositeOperation = "destination-out";
		ctx.fillStyle = gradient;

		ctx.beginPath();
		ctx.arc(
			(playerCoords.x + 0.5) * cellSize,
			(playerCoords.y + 0.5) * cellSize,
			visibleRadius,
			0,
			2 * Math.PI
		);
		ctx.fill();

		// 以及清除终点周围的迷雾
		var endCoords = maze.endCoord();
		ctx.beginPath();
		ctx.arc(
			(endCoords.x + 0.5) * cellSize,
			(endCoords.y + 0.5) * cellSize,
			visibleRadius,
			0,
			2 * Math.PI
		);
		ctx.fill();

		// 重新绘制终点的图像，制造终点雾蒙蒙的效果
		if (endSprite) {
			drawEndSprite();
		}
		// 恢复默认的合成操作
		ctx.globalCompositeOperation = "source-over";
	};

	// 重新绘制迷宫
	this.redrawMaze = function (size) {
		cellSize = size;
		ctx.lineWidth = cellSize / 50;
		drawMap();
		drawEndMethod();
		// 调用绘制Fog的方法
		if (this.fog) {
			this.drawFog(player.cellCoords);
		}
	};

	// 绘制一个单元格
	function drawCell(xCord, yCord, cell) {
		var x = xCord * cellSize;
		var y = yCord * cellSize;

		ctx.strokeStyle = "black"; // 设置墙的绘制颜色

		if (cell.n == false) {
			ctx.beginPath();
			ctx.moveTo(x, y);
			ctx.lineTo(x + cellSize, y);
			ctx.stroke();
		}
		if (cell.s === false) {
			ctx.beginPath();
			ctx.moveTo(x, y + cellSize);
			ctx.lineTo(x + cellSize, y + cellSize);
			ctx.stroke();
		}
		if (cell.e === false) {
			ctx.beginPath();
			ctx.moveTo(x + cellSize, y);
			ctx.lineTo(x + cellSize, y + cellSize);
			ctx.stroke();
		}
		if (cell.w === false) {
			ctx.beginPath();
			ctx.moveTo(x, y);
			ctx.lineTo(x, y + cellSize);
			ctx.stroke();
		}
	}

	// 绘制整个迷宫
	function drawMap() {
		for (x = 0; x < map.length; x++) {
			for (y = 0; y < map[x].length; y++) {
				drawCell(x, y, map[x][y]);
			}
		}
	}

	// 绘制终点的标志
	function drawEndFlag() {
		var coord = Maze.endCoord();
		var gridSize = 4;
		var fraction = cellSize / gridSize - 2;
		var colorSwap = true;
		for (let y = 0; y < gridSize; y++) {
			if (gridSize % 2 == 0) {
				colorSwap = !colorSwap;
			}
			for (let x = 0; x < gridSize; x++) {
				ctx.beginPath();
				ctx.rect(
					coord.x * cellSize + x * fraction + 4.5,
					coord.y * cellSize + y * fraction + 4.5,
					fraction,
					fraction
				);
				if (colorSwap) {
					ctx.fillStyle = "rgba(0, 0, 0, 0.8)";
				} else {
					ctx.fillStyle = "rgba(255, 255, 255, 0.8)";
				}
				ctx.fill();
				colorSwap = !colorSwap;
			}
		}
	}

	// 绘制终点的图像
	function drawEndSprite() {
		var offsetLeft = cellSize / 50;
		var offsetRight = cellSize / 25;
		var coord = Maze.endCoord();
		ctx.drawImage(
			endSprite,
			2,
			2,
			endSprite.width,
			endSprite.height,
			coord.x * cellSize + offsetLeft,
			coord.y * cellSize + offsetLeft,
			cellSize - offsetRight,
			cellSize - offsetRight
		);
	}

	// 清除canvas
	function clear() {
		var canvasSize = cellSize * map.length;
		ctx.clearRect(0, 0, canvasSize, canvasSize);
	}

	// 如果没有终点图像，则绘制默认的标志
	if (endSprite != null) {
		drawEndMethod = drawEndSprite;
	} else {
		drawEndMethod = drawEndFlag;
	}
	clear();
	drawMap();
	drawEndMethod();
}

// ------------------------------------------------------------------ 在迷宫中创建和控制一个玩家
function Player(maze, c, _cellsize, onComplete, sprite = null) {
	var ctx = c.getContext("2d");
	var drawSprite;
	var moves = 0;
	drawSprite = drawSpriteCircle;
	if (sprite != null) {
		drawSprite = drawSpriteImg;
	}
	var player = this;
	var map = maze.map();
	var cellCoords = {
		x: maze.startCoord().x,
		y: maze.startCoord().y,
	};
	var cellSize = _cellsize;
	var halfCellSize = cellSize / 2;

	// 重新绘制玩家
	this.redrawPlayer = function (_cellsize) {
		cellSize = _cellsize;
		drawSpriteImg(cellCoords);
	};

	this.startTime = performance.now(); // 在这里设置startTime

	// 默认绘制一个圆形的玩家
	function drawSpriteCircle(coord) {
		ctx.beginPath();
		ctx.fillStyle = "yellow";
		ctx.arc(
			(coord.x + 1) * cellSize - halfCellSize,
			(coord.y + 1) * cellSize - halfCellSize,
			halfCellSize - 2,
			0,
			2 * Math.PI
		);
		ctx.fill();
		if (coord.x === maze.endCoord().x && coord.y === maze.endCoord().y) {
			onComplete(moves);
			player.unbindKeyDown();
		}
	}

	// 绘制一个图像的玩家
	function drawSpriteImg(coord) {
		var offsetLeft = cellSize / 50;
		var offsetRight = cellSize / 25;
		ctx.drawImage(
			sprite,
			0,
			0,
			sprite.width,
			sprite.height,
			coord.x * cellSize + offsetLeft,
			coord.y * cellSize + offsetLeft,
			cellSize - offsetRight,
			cellSize - offsetRight
		);
		if (coord.x === maze.endCoord().x && coord.y === maze.endCoord().y) {
			onComplete(moves);
			player.unbindKeyDown();
		}
	}

	// 移除玩家的图像
	function removeSprite(coord) {
		var offsetLeft = cellSize / 50;
		var offsetRight = cellSize / 25;
		ctx.clearRect(
			coord.x * cellSize + offsetLeft,
			coord.y * cellSize + offsetLeft,
			cellSize - offsetRight,
			cellSize - offsetRight
		);
	}

	// ---------------------------------------------- 检查玩家的移动，只有当玩家真正移动时，才增加步数
	function check(e) {
		var cell = map[cellCoords.x][cellCoords.y];
		var moved = false;
		switch (e.keyCode) {
			case 65:
			case 37: // west
				if (cell.w == true) {
					moves++;
					removeSprite(cellCoords);
					cellCoords = {
						x: cellCoords.x - 1,
						y: cellCoords.y,
					};
					drawSprite(cellCoords);
					moved = true;
				}
				break;
			case 87:
			case 38: // north
				if (cell.n == true) {
					moves++;
					removeSprite(cellCoords);
					cellCoords = {
						x: cellCoords.x,
						y: cellCoords.y - 1,
					};
					drawSprite(cellCoords);
					moved = true;
				}
				break;
			case 68:
			case 39: // east
				if (cell.e == true) {
					moves++;
					removeSprite(cellCoords);
					cellCoords = {
						x: cellCoords.x + 1,
						y: cellCoords.y,
					};
					drawSprite(cellCoords);
					moved = true;
				}
				break;
			case 83:
			case 40: // south
				if (cell.s == true) {
					moves++;
					removeSprite(cellCoords);
					cellCoords = {
						x: cellCoords.x,
						y: cellCoords.y + 1,
					};
					drawSprite(cellCoords);
					moved = true;
				}
				break;
		}
		// 调用绘制Fog的方法
		if (draw.fog) {
			draw.drawFog(cellCoords);
		}
		if (!moved) {
			document.getElementById("wall").play();
		}
	}

	// 绑定键盘事件
	this.bindKeyDown = function () {
		window.addEventListener("keydown", check, false);

		$("#view").swipe({
			swipe: function (
				event,
				direction,
				distance,
				duration,
				fingerCount,
				fingerData
			) {
				console.log(direction);
				switch (direction) {
					case "up":
						check({
							keyCode: 38,
						});
						break;
					case "down":
						check({
							keyCode: 40,
						});
						break;
					case "left":
						check({
							keyCode: 37,
						});
						break;
					case "right":
						check({
							keyCode: 39,
						});
						break;
				}
			},
			threshold: 0,
		});
	};

	// 解绑键盘事件
	this.unbindKeyDown = function () {
		window.removeEventListener("keydown", check, false);
		$("#view").swipe("destroy");
	};

	drawSprite(maze.startCoord());

	this.bindKeyDown();
}

// ------------------------------------------------------------------ 迷宫基础设置
var mazeCanvas = document.getElementById("mazeCanvas");
var ctx = mazeCanvas.getContext("2d");
var sprite; // 玩家的图像
var finishSprite; // 终点的图像
var maze, draw, player;
var cellSize; // 每个单元格的大小
var difficulty; // 迷宫的难度
// sprite.src = 'media/sprite.png';

window.onload = function () {
	let viewWidth = $("#view").width();
	let viewHeight = $("#view").height();
	if (viewHeight < viewWidth) {
		ctx.canvas.width = viewHeight - viewHeight / 100;
		ctx.canvas.height = viewHeight - viewHeight / 100;
	} else {
		ctx.canvas.width = viewWidth - viewWidth / 100;
		ctx.canvas.height = viewWidth - viewWidth / 100;
	}

	//Load and edit sprites
	var completeOne = false;
	var completeTwo = false;
	var isComplete = () => {
		if (completeOne === true && completeTwo === true) {
			console.log("Runs");
			setTimeout(function () {
				makeMaze();
			}, 500);
		}
	};
	sprite = new Image();
	sprite.src =
		"https://i.ibb.co/c8DnVSG/1-12-icon-icons-com-68880.png" +
		"?" +
		new Date().getTime();
	sprite.setAttribute("crossOrigin", " ");
	sprite.onload = function () {
		sprite = changeBrightness(1.2, sprite);
		completeOne = true;
		console.log(completeOne);
		isComplete();
	};

	finishSprite = new Image();
	finishSprite.src =
		"https://i.ibb.co/g7p9R1c/door-icon-126434.png" +
		"?" +
		new Date().getTime();
	finishSprite.setAttribute("crossOrigin", " ");
	finishSprite.onload = function () {
		finishSprite = changeBrightness(1.1, finishSprite);
		completeTwo = true;
		console.log(completeTwo);
		isComplete();
	};
};

window.onresize = function () {
	let viewWidth = $("#view").width();
	let viewHeight = $("#view").height();
	if (viewHeight < viewWidth) {
		ctx.canvas.width = viewHeight - viewHeight / 100;
		ctx.canvas.height = viewHeight - viewHeight / 100;
	} else {
		ctx.canvas.width = viewWidth - viewWidth / 100;
		ctx.canvas.height = viewWidth - viewWidth / 100;
	}
	cellSize = mazeCanvas.width / difficulty;
	if (player != null) {
		draw.redrawMaze(cellSize);
		player.redrawPlayer(cellSize);
	}
};

// 难度选择
document.getElementById("diffSelect").addEventListener("change", function () {
	if (this.value === "custom") {
		document.getElementById("customInput").style.visibility = "visible";
	} else {
		document.getElementById("customInput").style.visibility = "hidden";
	}
});

// ------------------------------------------------------------------ 生成迷宫
function makeMaze() {
	if (player != undefined) {
		player.unbindKeyDown();
		player = null;
	}
	var e = document.getElementById("diffSelect");
	var difficulty =
		e.value === "custom"
			? document.getElementById("customInput").value
			: e.options[e.selectedIndex].value;
	cellSize = mazeCanvas.width / difficulty;
	maze = new Maze(difficulty, difficulty);
	draw = new DrawMaze(maze, ctx, cellSize, finishSprite);
	player = new Player(maze, mazeCanvas, cellSize, displayVictoryMess, sprite);
	if (document.getElementById("mazeContainer").style.opacity < "100") {
		document.getElementById("mazeContainer").style.opacity = "100";
	}
	// 沿用Fog设置
	if (document.getElementById("fogCheckbox").checked) {
		draw.enableFog();
	} else {
		draw.disableFog();
	}

	// 计算分数
	function calculateScore(steps, time, minSteps, maxSteps, maxTime) {
		var score = 100 * (1 - (steps - minSteps) / maxSteps - time / maxTime);
		return Math.max(0, score.toFixed(2)); // 保留两位小数，且得分不低于0
	}

	// 通关信息
	function displayVictoryMess(moves) {
		var endTime = performance.now();
		var timeElapsed = ((endTime - player.startTime) / 1000).toFixed(2); // 计算通关时间并转换为秒，保留两位小数
		var fogMode = document.getElementById("fogCheckbox").checked; // 检查是否开启了雾模式

		// 计算minsteps
		function findShortestPath(maze) {
			var startCoord = maze.startCoord();
			var endCoord = maze.endCoord();
			var queue = [startCoord];
			var visited = new Set();
			var distance = {};
			var key = (coord) => coord.x + "," + coord.y;

			distance[key(startCoord)] = 0;

			while (queue.length > 0) {
				var current = queue.shift();
				var currentKey = key(current);

				if (current.x === endCoord.x && current.y === endCoord.y) {
					// 到达终点
					return distance[currentKey];
				}

				for (var direction of ["n", "s", "e", "w"]) {
					if (maze.map()[current.x][current.y][direction]) {
						var next = {
							x:
								current.x +
								(direction === "e" ? 1 : direction === "w" ? -1 : 0),
							y:
								current.y +
								(direction === "s" ? 1 : direction === "n" ? -1 : 0),
						};
						var nextKey = key(next);

						if (!visited.has(nextKey)) {
							queue.push(next);
							visited.add(nextKey);
							distance[nextKey] = distance[currentKey] + 1;
						}
					}
				}
			}

			// 如果没有找到路径，返回无穷大
			return Infinity;
		}

		// 在生成迷宫后，运行BFS来找到最短路径
		var minSteps = findShortestPath(maze);

		// 在计算分数之前保存原始的 minSteps 值
		var originalMinSteps = minSteps;

		// 如果开启了雾模式，将minSteps乘以 y = 1.01^a
		if (fogMode) {
			var factor = Math.pow(1.01, difficulty);
			minSteps *= factor;
		}

		var maxSteps = difficulty * difficulty; // 假设max为迷宫的单元格数量的平方
		var maxTime = maxSteps * 2;

		if (isMobileDevice()) {
			// 如果用户使用的是移动设备，那么最大时间设为max*5
			maxTime = maxSteps * 5;
		}
		var score = calculateScore(moves, timeElapsed, minSteps, maxSteps, maxTime);
		document.getElementById("moves").innerHTML =
			"You Moved <b>" +
			moves +
			"</b> Steps. <br /> Minimum Possible Steps: <b>" +
			originalMinSteps +
			"</b><br /> Spent Time : <b>" +
			timeElapsed +
			"</b> s. <br /> Your Score: <b>" +
			score;

		toggleVisablity("Message-Container");
		document.getElementById("victory").play();
	}

	document.getElementById("moves").className = "score";
}

// 开关Fog
document.getElementById("fogCheckbox").addEventListener("change", function () {
	if (this.checked) {
		draw.enableFog();
	} else {
		draw.disableFog();
	}
});

// ------------------------------------------------------------------ 判断是否是移动设备
function isMobileDevice() {
	// 判断用户的设备是否含有触摸屏
	var hasTouchScreen = false;
	if ("maxTouchPoints" in navigator) {
		hasTouchScreen = navigator.maxTouchPoints > 0;
	} else if ("msMaxTouchPoints" in navigator) {
		hasTouchScreen = navigator.msMaxTouchPoints > 0;
	} else {
		var mQ = window.matchMedia && matchMedia("(pointer:coarse)");
		if (mQ && mQ.media === "(pointer:coarse)") {
			hasTouchScreen = !!mQ.matches;
		} else if ("orientation" in window) {
			hasTouchScreen = true; // 假设所有带有方向感应的设备都是触摸屏
		} else {
			// 使用一些常见的移动设备的特征来判断
			var ua = navigator.userAgent;
			var regex =
				/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i;
			hasTouchScreen = regex.test(ua);
		}
	}
	return hasTouchScreen;
}