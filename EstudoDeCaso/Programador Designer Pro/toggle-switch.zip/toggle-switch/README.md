# Toggle Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/LYXEEqO](https://codepen.io/Codewithshobhit/pen/LYXEEqO).

All-CSS toggle UI with background change. Radios were used because of their innate mutual-exclusivity. No JS needed.