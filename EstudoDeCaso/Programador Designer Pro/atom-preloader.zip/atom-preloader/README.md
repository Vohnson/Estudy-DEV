# Atom Preloader

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/VwEVYWQ](https://codepen.io/Codewithshobhit/pen/VwEVYWQ).

This (carbon-13) atom is made up of SVG electron orbits and “3D” CSS protons and neutrons.