# Gameboy Tetris

<h1>Programador Designer Pro</h1>

Curta, Compartilha, Salva, Comenta, Siga-nos

<a href="https://www.instagram.com/programadordesignerpro/">Instagram</a>.
<a href="https://t.me/programadordesignerpro">Telegram</a>.

Ajuda muito o meu Trabalho.

Uma versão javascript simples do Tetris para o GameBoy. Embora seja bastante semelhante a todas as versões do Tetris. Usa p5.js para desenhar!

https://p5js.org/
https://en.wikipedia.org/wiki/Tetris
