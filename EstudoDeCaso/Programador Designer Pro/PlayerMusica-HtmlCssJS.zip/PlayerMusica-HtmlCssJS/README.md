# music player widget

A Pen created on CodePen.io. Original URL: [https://codepen.io/abxlfazl/pen/YzGEVRP](https://codepen.io/abxlfazl/pen/YzGEVRP).

Designed by:  Mauricio Bucardo
Original image: https://dribbble.com/shots/6957353-Music-Player-Widget

Github: https://github.com/abxlfazl/music-player-widget