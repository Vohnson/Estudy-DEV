# Human X-ray with CSS 

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/zYJwmOE](https://codepen.io/Codewithshobhit/pen/zYJwmOE).

