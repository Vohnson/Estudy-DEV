const alertButton = document.getElementById('alert-button');

alertButton.addEventListener('click', function() {
    alert('Você clicou no botão!');
});
