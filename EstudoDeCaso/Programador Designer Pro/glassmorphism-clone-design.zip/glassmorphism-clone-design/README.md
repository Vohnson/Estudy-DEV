# Clone do aplicativo Glassmorphism Creative Cloud

Inpirado em Mikołaj Gałęziowski
"https://dribbble.com/shots/14831798-Glassmorphism-Big-Sur-Creative-Cloud-App-Redesign"

<h1>Programador Designer Pro</h1>
ツ ESPERO QUE VOCÊS APRECIEM!

Curta, Compartilha, Salva, Comenta, Siga-nos

<a href="https://www.instagram.com/programadordesignerpro/">Instagram</a>.
<a href="https://t.me/programadordesignerpro">Telegram</a>.

Ajuda muito o meu Trabalho.
