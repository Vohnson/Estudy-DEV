# Turning pages with CSS

A Pen created on CodePen.io. Original URL: [https://codepen.io/Codewithshobhit/pen/GRXWrEy](https://codepen.io/Codewithshobhit/pen/GRXWrEy).

