// @AbubakerSaeed96 (twitter)
// abubakersaeed.netlify.com
// =========================

// Suppose Javascript is off and there is some important content we want our users to see via modal, we can use this approach.

// Thank You for Viewing.

// CSS Modal v1:
// That version is in light mode and has little different design than this one
// https://codepen.io/AbubakerSaeed/pen/qBWRGNm